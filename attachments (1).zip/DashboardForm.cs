namespace WinFormsApp4;

internal partial class DashboardForm : Form
{
    public DashboardForm(UserAccount account)
    {
        InitializeComponent();
        userLabel.Text = $"{account.Name}\n{account.Email}";
        logoutButton.Click += LogoutButton_Click;
    }

    private void LogoutButton_Click(object? sender, EventArgs e)
    {
        Close();
    }
}
